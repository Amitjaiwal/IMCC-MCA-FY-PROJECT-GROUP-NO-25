<html>
<body><center><h2><b><caption>
<form action = "<?php $_PHP_SELF ?>" method = "POST" />
Enter user name = 
<input type = "text" name = "t1"/> </br> </br>
Enter login name=
<input type = "text" name = "t2"/> </br> </br>
Enter password = 
<input type = "password" name = "p1"/></br></br>
<input type = "submit" value = "register now " />

<input type = "submit" value = " cancel " />
<center/><b/></h2><caption/></form>
</body>


