<html>
<head>
<style>
.button {
  background-color: black;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}
</style>

<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" href="login1css.css">
</head>

<body>
<center><h1 class="text-center text-black pt-5">Sign up new user</h1></center>


 <div class="container">
            <div id="login-row" class="row justify-content-center align-items-center">
                <div id="login-column" class="col-md-6">
                    <div id="login-box" class="col-md-12">

<form id="login-form" class="form" action = "userinsert.php" method = "POST" />





<h3 class="text-center text-black font-weight-bold">Sign up</h3><br>
                            <div class="form-group">
                                <label for="username" class="text-black font-weight-bold">Username:</label><br>
                                <input type="text" name="t1" id="t1" class="form-control"placeholder="Enter your username" required/>
                            </div>
                            <div class="form-group">
                                <label for="login name" class="text-black font-weight-bold">login name:</label><br>
                                <input type="text" name="t2" id="t2" class="form-control"placeholder="Enter your name" required/>
                            </div>
                            <div class="form-group">
                                <label for="password" class="text-black font-weight-bold">Password:</label><br>
                                <input type="password" name="p1" id="p1" class="form-control" placeholder="Enter your password" required/>
                            </div>
                            
                                <br>
                                <center><input type="submit" name="submit" class="button" value="Submit"></center>
                            </div>

                            </div></form></div></div></div></div>
</form>
</body></html>


