<html><head>
   <link rel="stylesheet" href="https://www.w3schools.com/lib/w3-theme-red.css">
   <style type="text/css">
h1{
   font-size: 50px;
   color: black;
}
div{
   
   padding-top: 0px;

}

.button {
  background-color: black;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}




</style>
   
   </head>
   <body class="w3-theme">
<?php
   include("configdb5.php");
   session_start();

   
   if($_SERVER["REQUEST_METHOD"] == "POST") {
      // username and password sent from form 
      
      $a = mysqli_real_escape_string($db,$_POST['t1']);
      $b = mysqli_real_escape_string($db,$_POST['p1']); 
      
      $sql = "SELECT loginnm FROM logmast WHERE loginnm = '$a' and passwd = '$b'";
      $result = mysqli_query($db,$sql);
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
      
      $count = mysqli_num_rows($result);
      
      // If result matched $a and $b, table row must be 1 row
		
      if($count == 1) 
{
   header("location: vacancyinter.php");
        echo "<h1>login succeed</h1>";


echo  '<a href="vacancyinter.php"><h1>Click here to place your  International order </h1></a>';
      }
      else {
      
         echo "<br><br><br><center><h2>Your Login Name or Password is invalid</h2><br><br><br>";
      }
   }
?>
 <center> <div> <a href="login3.php" class="button">BACK TO LOGIN PAGE</a> </div> </center>
 </body>
</html>