<html>
   
   <head>
       <title>Quotation</title>
       
      <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
       <link rel="stylesheet" type="text/css" href="abc.css">
   

   <script type="text/javascript">

 function allLetter(inputtxt)
  {
   var letters = /^[A-Za-z]+$/;
   if(inputtxt.value.match(letters))
     {
      return true;
     }
   else
     {
     alert("Please enter only alphabets in the company name");
     inputtxt.value="";
     inputtxt.focus();
     return false;
     }
  }



function allLetter1(inputtxt)
  {
   var letters = /^[A-Za-z]+$/;
   if(inputtxt.value.match(letters))
     {
      return true;
     }
   else
     {
     alert("Please enter only alphabets in the company-owner name");
     inputtxt.value="";
     inputtxt.focus();
     return false;
     }
  }

function allnumeric(inputtxt)
   {
      var numbers = /^[0-9]+$/;
      if(inputtxt.value.match(numbers))
      {
      
      return true;
      }
      else
      {
      alert('Please input digit only in mobile number');

      inputtxt.value="";
     inputtxt.focus();
      return false;
      }
   } 
</script>
         
      
      
   </head>
   <Center><h1>Quality Packers and Movers</h1>
<br>

Service Request For Professional Package
</Center><br>
   <body>

<div align="center">
    
         <div style = "width:600px; " align = "left">
            <div style = "color:white; padding:5px;"><b><center><h3>Quotation</center> </b></h3></div>
				
            <div style = "margin:30px">

                 <form  name="form1" action = "insert3.php" method = "post">
                   
 <div class="form-group">
    						<label>Company_Name</label>
    						<input type="text" name="t1" class="form-control" placeholder="Enter your name" required>
    					</div>                 
 <div class="form-group">
    						<label>Full Name</label>
    						<input type="text" name="t2" class="form-control" placeholder="Enter your name" required>
    					</div>
<div class="form-group">
    						<label>Mobile No</label>
    						<input type=maxlength="number" name="t3" class="form-control" maxlength="10" placeholder="Enter your number"required>
    					</div>
    					<div class="form-group">
    							<label>Pickup_date</label>
    						<input type="date" name="t4" class="form-control" min="2021-09-01" max="2023-01-01" required>
    					</div>
						<div class="form-group">
    						<label>Pickup</label>
    						<input type="text" name="t5" class="form-control"placeholder="Enter Pickup location" required>
    					</div><div class="form-group">
    						<label>Drop</label>
    						<input type="text" name="t6" class="form-control"placeholder="Enter drop location" required>
    						</div>

    					<div class="form-group">
    						<label>Email</label>
    						<input type="Email" name="t7" class="form-control"placeholder="Enter your Email" required>
    					</div><div class="form-group">
    						<label>Comment</label>
    						<input type="text" name="t8" class="form-control" placeholder="Enter your message"required>
    					</div>
<div align="center">
                  <button type="submit" class="btn btn-primary" onclick="allLetter(document.form1.t1); allLetter1(document.form1.t2); 
                  allnumeric(document.form1.t3);">Submit</button>    
               </form>
               
              
					
         </div>				
         </div>
			
      </div>

   </body>
</html>
