<html>
<head>
	<link rel="stylesheet" href="https://www.w3schools.com/lib/w3-theme-red.css">
	<style type="text/css">
h1{
	font-size: 50px;
	color: black;
}
div{
	
	padding-top: 0px;
}
.button {
  background-color: black;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}
</style>
	
	</head>
	<body class="w3-theme">
<?php 
   include("configdb5.php");
   session_start();
  if($_SERVER["REQUEST_METHOD"] == "POST") 
{
$a=mysqli_real_escape_string($db,$_POST['t1']);
$b=mysqli_real_escape_string($db,$_POST['t2']); 
$c=mysqli_real_escape_string($db,$_POST['t3']);
$d=mysqli_real_escape_string($db,$_POST['t4']); 
$e=mysqli_real_escape_string($db,$_POST['t5']);
$f=mysqli_real_escape_string($db,$_POST['t6']); 
$g=mysqli_real_escape_string($db,$_POST['t7']);
$h=mysqli_real_escape_string($db,$_POST['t8']);

$sql = "insert into inter values (NULL,'$a','$b','$c','$d','$e','$f','$g','$h')";

  if(mysqli_query($db,$sql))
echo "<script> alert('Your Request Is Submitted Successfully... we will contact you soon');</script>";
   else
  echo "insert failed";
}
?>
<h1><center> Quality Movers and Packers </center></h1>

<center><h2><br><br><br>Thank you.Your request has been proccessed.</h2></center></body><br><br><br>
<div><center><button onclick="location.href='main.php'"class="button" >Back to Home</button></center></div></body>
</html>






