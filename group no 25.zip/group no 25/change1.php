<html>
<body>
<h1><center>Change password page </h1></center>
</body>
<style>
body{background-image:url("g.jpg");
background-repeat:no-repeat;
background-attachment:fixed;
background-size:100% 100%;}
</style>
<body><center><h2><b><caption>
<form action = "userinsert.php" method = "POST" />
<br><br><br><br><br><br><br>
Old Password = 
<input type = "text" name = "t1"/> </br> </br>
Enter New Password =
<input type = "text" name = "t2"/> </br> </br>
Confirm Password = 
<input type = "password" name = "p1"/></br></br>
<input type = "submit" value = "change password" />

<input type = "submit" value = " cancel " />
<center/><b/></h2><caption/></form>
</body>


