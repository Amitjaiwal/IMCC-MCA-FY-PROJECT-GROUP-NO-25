<html>
<head>
<style>
body
{background-color : "#FFEBCD"; font-size:"20pt"; border-style : "double";}

</style>
<h1><marquee>Quality packers and movers </marquee></h1>
<h1> Domestic Shifting List Detail</h1>
</head>
<body>
<?php
   include("configdb5.php");
   session_start();
 
$sql = "select * from domestic" ;
  
 $result = mysqli_query($db,$sql);
 if (mysqli_num_rows($result)>0)
{
echo "<table border ='1'><tr> <th>Order Id</th> <th>Full Name</th><th>Mobile No</th><th>Pick Date</th><th>Pick Up</th>
<th>Drop</th><th>Email</th><th>Comment</th></tr>";
   
while ($row = mysqli_fetch_assoc($result))
   {
    echo "<tr> <td>".  $row["incid"] . "</td>";
     echo "<td>".  $row["fnm"] . "</td>";
    echo " <td>".  $row["mob"] . "</td>";
    echo " <td>".  $row["pdt"] . "</td>";
    echo " <td>".  $row["ploc"] . "</td>";
    echo " <td>".  $row["dloc"] . "</td>";
       echo " <td>".  $row["email"] . "</td>";
    echo " <td>".  $row["comm"] . "</td>";
  
    echo "</tr>";
   }
echo "</table>";
}
?>
</body>