<html><head>
  <style>

</style>
<title>Home</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://www.w3schools.com/lib/w3-theme-red.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

</head>
<head>
<style>


.btn-group button {
  background-color: black;
  width: 80%;
  border: 1px solid white; 
  color: white;   padding: 20px 24px; 
  cursor: pointer; 
  float: center; 
  font-size: 28px;
  font-family: times new roman;


}

/* Clear floats (clearfix hack) */
.btn-group:after {

  content: "";
  clear: both;
  display: table;
}

.btn-group button:not(:last-child) {
  border-right: none; /* Prevent double borders */
}

/* Add a background color on hover */
.btn-group button:hover {
  background-color: red;
}
.pop{
  padding-left: 350px;
  padding-top: 100px;
 


}

</style>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://www.w3schools.com/lib/w3-theme-purple.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body class="w3-theme">
  <div class="pop">
<div class="w3-row-padding w3-center w3-padding-64" id="pricing">
   
 

    <div class="w3-third w3-margin-bottom">
      <ul class="w3-ul w3-border w3-hover-shadow">
        <li class="w3-theme-12">
          <p class="w3-xlarge">Are you a already user</p>
        </li>
        
        <li class="w3-theme-12 w3-padding-24">
          <button class="w3-button w3-teal w3-padding-large"><i class="fa fa-check"></i> <a href="login3.php" >Sign Up</a>  </button>
        </li>
      </ul>
    </div> 

   
    
    <div class="w3-third w3-margin-bottom">
      <ul class="w3-ul w3-border w3-hover-shadow">
        <li class="w3-theme">
          <p class="w3-xlarge">Not user then sign up here</p>
        </li>
        
        <li class="w3-theme-12 w3-padding-24">
          <button class="w3-button w3-teal w3-padding-large"><i class="fa fa-check"></i> <a href="sign.php">Sign Up</a></button>
        </li>
      </ul>
    </div>
  </div>
    <marquee direction="right"scrollamount="30"><img src="truck.png"  style="width:10% " ></marquee>
        
  
</body>
</html>
