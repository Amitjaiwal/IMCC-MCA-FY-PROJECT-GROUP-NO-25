
<html>
<head>
   <title>Home PAge</title>
    <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
   <link rel="stylesheet" type="text/css" href="style.css">
   
</head>
<body>
	<div class="container">
	<a class="float-right" href="logscreen.php">LOGOUT</a>
   <h1>Thank you for your co-operation </h1>
</div>
</body>
</html>