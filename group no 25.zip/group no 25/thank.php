<html
<body>
<div class="jumbotron text-center">
	<center>
  <h1 class="display-3">Thank You!</h1>
</center>
  <p class="lead"><strong>Please check your email</strong> for further instructions on how to complete your account setup.</p>
  
  <p class="lead">
  	<div id="center_button"><button onclick="location.href='main.php'">Back to Home</button></div>
    
  </p>
</div>
</body>
</html>