<html>
<head><head>
	<link rel="stylesheet" href="https://www.w3schools.com/lib/w3-theme-red.css">
	<style type="text/css">
h1{
	font-size: 50px;
	color: black;
}
div{
	
	padding-top: 0px;
}
.button {
  background-color: black;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}
</style>
	
	</head>
	<body class="w3-theme">
<?php 
   include("configdb5.php");
   session_start();
  if($_SERVER["REQUEST_METHOD"] == "POST") 
{
$a=mysqli_real_escape_string($db,$_POST['a1']);
$b=mysqli_real_escape_string($db,$_POST['b1']); 
$c=mysqli_real_escape_string($db,$_POST['c1']);
$d=mysqli_real_escape_string($db,$_POST['d1']); 
$e=mysqli_real_escape_string($db,$_POST['d2']);
$f=mysqli_real_escape_string($db,$_POST['d3']); 


$sql = "insert into feedback values ('$a','$b','$c','$d','$e','$f')";

  if(mysqli_query($db,$sql))
echo "<script> alert('Your Data Is Submitted Successfully... we will contact you soon');</script>";
   else
  echo "<center><h2>Insert Failed..Please retry..!!</h2></center>";
}
?>

<h1><center> Quality Movers and Packers </center></h1>

<center><h2><br><br><br>Thank you.We will contact you soon.</h2></center></body>
<div><center><button onclick="location.href='main.php'"class="button" >Back to Home</button></center></div></body>
</html>






