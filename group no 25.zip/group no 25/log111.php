<html>
<?php
   include("configdb5.php");
   session_start();

   
   if($_SERVER["REQUEST_METHOD"] == "POST") {
      // username and password sent from form 
      
      $a = mysqli_real_escape_string($db,$_POST['t1']);
      $b = mysqli_real_escape_string($db,$_POST['p1']); 
      
      $sql = "SELECT loginnm FROM logmast WHERE loginnm = '$a' and passwd = '$b'";
      $result = mysqli_query($db,$sql);
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
      
      $count = mysqli_num_rows($result);
      
      // If result matched $a and $b, table row must be 1 row
		
      if($count == 1) 
{
   
   header("location: tech.php");
        echo "<h1>login succeed</h1>";

echo  '<a href="tech.php"><h1> Goto Admin Inbox </h1></a>';
}
      else {
      
         echo "Your Login Name or Password is invalid";
      }
   }
?>
</html>