<!DOCTYPE html>
<html lang="en">
<title>welcome</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body,h1,h2,h3,h4,h5,h6 {font-family: "Lato", sans-serif}
.w3-bar,h1,button {font-family: "Montserrat", sans-serif}
.fa-anchor,.fa-coffee {font-size:200px}
</style>
<body>

<form action = "main.php" method = "post">



<!-- Header -->
<header class="w3-container w3-red w3-center" style="padding:128px 16px">
  <h1 class="w3-margin w3-jumbo">WELCOME</h1>
  <button type="submit" class="w3-button w3-black w3-padding-large w3-large w3-margin-top">Get Started</button>
</header>

<!-- First Grid -->
<div class="w3-row-padding w3-padding-64 w3-container">
  <div class="w3-content">
    <div class="w3-twothird">
      <h1>Quality Packers and Movers</h1>
      <h5 class="w3-padding-32">

      Quality packers and movers helps people and businesses move their goods from one place to another.We offers all inclusive services for relocations like packing, loading, moving, unloading, unpacking, arranging of items to be shifted. Additional services may include cleaning services for houses, offices or warehousing facilities.</h5>
    </div>

    <div class="w3-third w3-center">
      <i class="fa fa-anchor w3-padding-64 w3-text-red"></i>
    </div>
  </div>
</div>

<!-- Second Grid -->


<div class="w3-container w3-black w3-center w3-opacity w3-padding-64">
    <h1 class="w3-margin w3-xlarge">Project done by:</h1>
    <h3>Manasi Janapurkar <br>
      Amit Jaiwal<br>
      Heramb Adghare<br>
      Sumedha Dalvi
    </h3>

</div>
<marquee direction="right"scrollamount="30"><img src="truck.png" alt="Boss" style="width:10%" ></marquee>


</body>
</html>