<html>
<head>
<style>
body
{background-color : "#FFEBCD"; font-size:"50pt"; border-style : "double";}

</style>
<h1><marquee>Quality packers and movers </marquee></h1>
<h1> International Shifting List Detail</h1>
</head>
<body>
<?php
   include("configdb5.php");
   session_start();
 
$sql = "select * from inter" ;
  
 $result = mysqli_query($db,$sql);
 if (mysqli_num_rows($result)>0)
{
echo "<table border ='1'><tr> <th>Company Name</th> <th>Full Name</th><th>Mobile No</th><th>Pick Date</th><th>Pick Up</th><th>Drop</th><th>Email</th><th>Comment</th><th>Drop Person Name</th><th>Drop Person No</th></tr>";
   
while ($row = mysqli_fetch_assoc($result))
   {
     echo "<tr> <td>".  $row["incid"] . "</td>";
    echo " <td>".  $row["cnm"] . "</td>";
    echo " <td>".  $row["pnm"] . "</td>";
    echo " <td>".  $row["mob"] . "</td>";
    echo " <td>".  $row["pdt"] . "</td>";
    echo " <td>".  $row["ploc"] . "</td>";
    echo " <td>".  $row["dloc"] . "</td>";
    echo " <td>".  $row["email"] . "</td>";
    echo " <td>".  $row["comm"] . "</td>";
    echo " <td>".  $row["dpnm"] . "</td>";
    echo " <td>".  $row["dmob"] . "</td>";
  
    echo "</tr>";
   }
echo "</table>";
}
?>
</body>