<html>
   
   <head>
   	<link rel="stylesheet" type="text/css" href="ab.css">
   	<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
   



      <title>Login Page</title>
      
      <style type = "text/css">
         
      </style>
      
   </head>
   <div align="center";
   <body bgcolor = "#FFD770"; color ="blue">

      <div align = "center" class="pop">
         <div style = "width:600px;  " align = "center">
            <div style = "background-color:black;color:white; padding:3px;"><h3><b>Login</b></h3></div>
         <div style = "margin:30px">
               
               <form action = "log11.php" method = "post">
                  <label>UserName: </label><input type = "text" name ="t1" class="box" placeholder="   Enter your name" required/><br /><br />
                  <label>Password: </label><input type = "password" name = "p1" class="box" placeholder="   Enter your password" required/><br/><br />
                  <button type="submit" class="btn btn-primary">Submit</button><br>

        <div class="abc"> <a href="sign.php"> Sign up New User </a><br/>
        <a href="change1.php"> Change Password </a><br/></div>

               </form>
               
              
					
            </div>
				
         </div>
			
      </div>

   </body>
</html>
