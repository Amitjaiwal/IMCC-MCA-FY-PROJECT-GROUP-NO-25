 <html>
<head>
<style>
body
{background-color : "#FFEBCD"; font-size:"20pt"; border-style : "double";}

</style>
<h1><marquee>MGM's JNEC Campus Recruitment System </marquee></h1>
<h1> Vacancy Details List</h1>
</head>
<body>
<?php
   include("config.php");
   session_start();
 
$sql = "select * from vacancy" ;
  
 $result = mysqli_query($db,$sql);
 if (mysqli_num_rows($result)>0)
{
echo "<table border ='1'><tr> <th>Vacancy Code</th><th>Name of Post</th><th>Qualifications</th>
<th>Terms </th><th>Job Location</th><th>Salary Package</th><th>Interview date and Time</th><th>Interview Venue </th></tr>";
   
while ($row = mysqli_fetch_assoc($result))
   {
     echo "<tr> <td>".  $row["vcode"] . "</td>";
    echo " <td>".  $row["post"] . "</td>";
    echo " <td>".  $row["qua"] . "</td>";
    echo " <td>".  $row["term"] . "</td>";
    echo " <td>".  $row["loc"] . "</td>";
        echo " <td>".  $row["salary"] . "</td>";
    echo " <td>".  $row["idate"] . "</td>";
   echo " <td>".  $row["venue"] . "</td>";
    echo "</tr>";
   }
echo "</table>";
}
?>
</body>