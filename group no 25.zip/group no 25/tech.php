<html>
<head>
<style>


  body{

          
            font-size:30px;
            
            padding-top: 30px;
   
         }

.btn-group button {
  background-color: black;
  width: 80%;
  border: 1px solid white; 
  color: white;   padding: 20px 24px; 
  cursor: pointer; 
  float: center; 
  font-size: 28px;
  font-family: times new roman;


}

/* Clear floats (clearfix hack) */
.btn-group:after {

  content: "";
  clear: both;
  display: table;
}

.btn-group button:not(:last-child) {
  border-right: none; /* Prevent double borders */
}

/* Add a background color on hover */
.btn-group button:hover {
  background-color: red;
}

</style>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://www.w3schools.com/lib/w3-theme-red.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body class="w3-theme">

<center><h1>Order Type</h1>

<div class="btn-group" style="padding-top: 130px" >
  <button ><a href="orders.php"> Domestic</a></button>
  <button><a href="ordersprof.php">Corporate</a></button>
  <button><a href="ordersinter.php">International</a></button>
  <button><a href="ordersfeed.php">Feedback</a></button>
</div>
</center>
</body>
</html>
