<!DOCTYPE html>
<html>
<head>
  <style>
    html {
  scroll-behavior: smooth;
}
.lop {
  
  -webkit-transition: width 2s, height 2s, -webkit-transform 2s; /* Safari */
  transition: width 2s, height 2s, transform 2s;
}

.lop:hover {
  -webkit-transform: rotate(360deg); /* Safari */
  transform: rotate(360deg);
}
</style>
<title>Home</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://www.w3schools.com/lib/w3-theme-red.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script type="text/javascript">
function allLetter2(inputtxt)
  {
   var letters = /^[A-Za-z]+$/;
   if(inputtxt.value.match(letters))
     {
      return true;
     }
   else
     {
     alert("please enter only alphabets in the company name");
     inputtxt.value="";
     inputtxt.focus();
     return false;
     }
  }
</script>
</head>
<body id="myPage">




<!-- Navbar -->
<div class="w3-top">
 <div class="w3-bar w3-theme-d2 w3-left-align">
  <a class="w3-bar-item w3-button w3-hide-medium w3-hide-large w3-right w3-hover-white w3-theme-d2" href="javascript:void(0);" onclick="openNav()"><i class="fa fa-bars"></i></a><h4>
  <a href="#" class="w3-bar-item w3-button w3-theme-red" ><i class="fa fa-home w3-margin-right"></i>Home</a>
  <a href="#team" class="w3-bar-item w3-button w3-hide-small w3-hover-white">Perks</a>
  <a href="#work" class="w3-bar-item w3-button w3-hide-small w3-hover-white">Work</a>
  <a href="#pricing" class="w3-bar-item w3-button w3-hide-small w3-hover-white">Quotation</a>
  <a href="#contact" class="w3-bar-item w3-button w3-hide-small w3-hover-white">Contact</a>
<a href="logscreen.php" class="w3-bar-item w3-button w3-hide-small w3-hover-white">Admin</a>
<a href="branch.html" class="w3-bar-item w3-button w3-hide-small w3-hover-white">City</a>
<a href="formpage.html" class="w3-bar-item w3-button w3-hide-small w3-hover-white">Feedback</a>
<a href="clientt.php" class="w3-bar-item w3-button w3-hide-small w3-hover-white">Client</a></h4>
     </div>
  

  <!-- Navbar on small screens -->
  <div id="navDemo" class="w3-bar-block w3-theme-d2 w3-hide w3-hide-large w3-hide-medium" >
    <a href="#team" class="w3-bar-item w3-button">Perks</a>
    <a href="#work" class="w3-bar-item w3-button">Work</a>
    <a href="#pricing" class="w3-bar-item w3-button">Quotation</a>
    <a href="#contact" class="w3-bar-item w3-button">Contact</a>
    <a href="#" class="w3-bar-item w3-button">Search</a>
  </div>
</div>

<!-- Image Header -->

<div class="w3-display-container w3-animate-opacity">
  <img src="ima.jpg" alt="boat" style="width:100%;min-height:450px;max-height:600px; padding-top: 50px">
  <div class="w3-container w3-display-bottomleft w3-margin-bottom">  

  </div>
</div>



<!-- Team Container -->
<div class="w3-container w3-padding-64 w3-center" id="team">
<b><h2>PERKS</h2></b>


<div class="w3-row"><br>

<div class="w3-quarter">
  <img src="quality.png" alt="Boss" style="width:45%" class="lop">
  <h3>Quality</h3>
  
</div>

<div class="w3-quarter">
  <img src="sevice1.jpg" alt="Boss" style="width:45%" class="lop">
  <h3>Good Service</h3>
 
</div>

<div class="w3-quarter">
  <img src="choice2.jpg" alt="Boss" style="width:45%" class="lop">
  <h3>Package Choice</h3>
  
</div>

<div class="w3-quarter">
  <img src="after1.png" alt="Boss" style="width:45%" class="lop">
  <h3>After service</h3>
 
</div>

</div>
</div>

<!-- Work Row -->
<div class="w3-row-padding w3-padding-64 w3-theme-l1" id="work">

<div >
<center><h2>Our Work</h2>
  <i>
<p>Quality Packers and Movers offers a wide variety of moving services, from commercial moves for small and large companies to residential moves for homes and apartments. We provide local moves within Aurangabad as well as long distance moves to all cities in  and abroad. We offer full and partial packing services for your household goods or your business inventory. We also provide a storage facility for short and long terms.</p><p>
Our expert Movers And Packers staff are taught the skills to expertly handle every aspect of your move, including careful packing, protecting carpets, banisters and front doors, disassembling and assembling office and home furniture etc. Because you will be inviting our crews into your home and spending a great deal of time in their company we have taken special care only to employ courteous, respectful and friendly staff with the highest standards of behavior. They will be companions in your move and you’ll find the presence of an Quality Movers and Packers crew will transform a stressful move into a pleasurable experience.</p></i>
</center></div></div>





<!-- Pricing Row -->
<div class="w3-row-padding w3-center w3-padding-64" id="pricing">
    <h2>PRICING</h2>
    <p>Choose a pricing plan that fits your needs.</p><br>
    <div class="w3-third w3-margin-bottom">
      <ul class="w3-ul w3-border w3-hover-shadow">
        <li class="w3-theme">
          <p class="w3-xlarge">Basic</p>
        </li>
        <li class="w3-padding-16"><b>DOMESTIC SHIFTING</b> </li>
        <li class="w3-padding-16"><b>Home shifting</b> </li>
       
        <li class="w3-padding-16"><b>Endless</b> Support</li>
        <li class="w3-padding-16"><span class="w3-opacity">Starting from</span>
          <h2 class="w3-wide">&#x20B9;20,000</h2>
          
        </li>
        <li class="w3-theme-l5 w3-padding-24">
          <button class="w3-button w3-teal w3-padding-large"><i class="fa fa-check"></i> <a href="services\service1.html" >Sign Up</a>  </button>
        </li>
      </ul>
    </div>

    <div class="w3-third w3-margin-bottom">
      <ul class="w3-ul w3-border w3-hover-shadow">
        <li class="w3-theme-l2">
          <p class="w3-xlarge">Professional</p>
        </li>
        <li class="w3-padding-16"><b>CORPORATE SHIFTING</b> </li>
        <li class="w3-padding-16"><b>Office Shifting</b> </li>
     
        <li class="w3-padding-16"><b>Endless</b> Support</li>
        <li class="w3-padding-16"><span class="w3-opacity">Starting from</span>
          <h2 class="w3-wide">&#x20B9;50,000</h2>
          
        </li>
        <li class="w3-theme-l5 w3-padding-24">
          <button class="w3-button w3-teal w3-padding-large"><i class="fa fa-check"></i> <a href="services\service2.html">Sign Up</a></button>
        </li>
      </ul>
    </div>

    <div class="w3-third w3-margin-bottom">
      <ul class="w3-ul w3-border w3-hover-shadow">
        <li class="w3-theme">
          <p class="w3-xlarge">Premium</p>
        </li>
        <li class="w3-padding-16"><b>INTERNATIONAL SHIFTING</b> </li>
        <li class="w3-padding-16"><b>Shifting outside country</b> </li>
        
        <li class="w3-padding-16"><b>Endless</b> Support</li>
        <li class="w3-padding-16">
          <span class="w3-opacity">Starting from</span>
          <h2 class="w3-wide">&#x20B9;100,000</h2>
          
        </li>
        <li class="w3-theme-l5 w3-padding-24">
          <button class="w3-button w3-teal w3-padding-large"><i class="fa fa-check"></i> <a href="services\service3.html">Sign Up</a></button>
        </li>
      </ul>
    </div>
</div>

<!-- Contact Container -->
<div class="w3-container w3-padding-64 w3-theme-l5" id="contact">
  <div class="w3-row">
    <div class="w3-col m5">
    <div class="w3-padding-16"><span class="w3-xlarge w3-border-teal w3-bottombar">Contact Us</span></div>
      <h3>Address</h3>
      
      <p><i class="fa fa-map-marker w3-text-teal w3-xlarge"></i>India</p>
      <p><i class="fa fa-phone w3-text-teal w3-xlarge"></i>  8888337432</p>
      <p><i class="fa fa-envelope-o w3-text-teal w3-xlarge"></i>packers&movers@gmail.com</p>
    </div>
    <div class="w3-col m7">
      <form name="form1" class="w3-container w3-card-4 w3-padding-16 w3-white" action="insert7.php" method= "POST" target="_blank">
      <div class="w3-section">      
        <label>Name</label>
        <input class="w3-input" type="text" name="t1" required>
      </div>
      <div class="w3-section">      
        <label>Email</label>
        <input class="w3-input" type="Email" name="t2" required>
      </div>
      <div class="w3-section">      
        <label>Message</label>
        <input class="w3-input" type="text" name="t3" required>
      </div>  
      <input class="w3-check" type="checkbox" checked name="t4">
      <label>I Like it!</label>
      <button type="submit" class="w3-button w3-right w3-theme" onclick="allLetter2(document.form1.t1);">Send</button>
      </form>
    </div>
  </div>
</div>

<!-- Image of location/map -->
<img src="/w3images/map.jpg" class="w3-image w3-greyscale-min" style="width:100%;">

<!-- Footer -->
<footer class="w3-container w3-padding-32 w3-theme-d1 w3-center">
  <h4>Quality packers and movers</h4>
  
 

  <div style="position:relative;bottom:100px;z-index:1;" class="w3-tooltip w3-right">
    <span class="w3-text w3-padding w3-teal w3-hide-small">Go To Top</span>   
    <a class="w3-button w3-theme" href="#myPage"><span class="w3-xlarge">
    <i class="fa fa-chevron-circle-up"></i></span></a>
  </div>
  <marquee direction="right"scrollamount="30"><img src="truck.png" alt="Boss" style="width:10%" ></marquee>
</footer>



</body>
</html>
