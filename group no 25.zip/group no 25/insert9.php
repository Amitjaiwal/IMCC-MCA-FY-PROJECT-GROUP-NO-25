<html>
<head><h1><center> Quality Movers and Packers </center></h1></head>
<?php 
   include("configdb5.php");
   session_start();
  if($_SERVER["REQUEST_METHOD"] == "POST") 
{
$a=mysqli_real_escape_string($db,$_POST['t1']);
$b=mysqli_real_escape_string($db,$_POST['t2']); 
$c=mysqli_real_escape_string($db,$_POST['t3']);
$d=mysqli_real_escape_string($db,$_POST['t4']); 
$e=mysqli_real_escape_string($db,$_POST['t5']);
$f=mysqli_real_escape_string($db,$_POST['t6']); 
$g=mysqli_real_escape_string($db,$_POST['t7']);
$h=mysqli_real_escape_string($db,$_POST['t7']);

$sql = "insert into adomestic values ('$a','$b','$c','$d','$e','$f','$g')";

  if(mysqli_query($db,$sql))
echo "<script> alert('Your Request Is Submitted Successfully... we will contact you soon');</script>";
   else
  echo "insert failed";
}
?>
<A href="main.php"> Home </A>
</html>






