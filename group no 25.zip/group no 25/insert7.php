<html>
<head><head>
	<link rel="stylesheet" href="https://www.w3schools.com/lib/w3-theme-red.css">
	<style type="text/css">
h1{
	font-size: 50px;
	color: black;
}
div{
	
	padding-top: 0px;
}
</style>
	
	</head>
	<body class="w3-theme">
<?php 
   include("configdb5.php");
   session_start();
  if($_SERVER["REQUEST_METHOD"] == "POST") 
{
$a=mysqli_real_escape_string($db,$_POST['t1']);
$b=mysqli_real_escape_string($db,$_POST['t2']); 
$c=mysqli_real_escape_string($db,$_POST['t3']);
$d=mysqli_real_escape_string($db,$_POST['t4']); 


$sql = "insert into contact values (NULL,'$a','$b','$c','$d')";

  if(mysqli_query($db,$sql))
echo "<script> alert('Your Data Is Submitted Successfully...we will contact you soon..!!');</script>";
   else
  echo "Insert Failed";
}
?>

<h1><center> Quality Movers and Packers </center></h1>

<center><h2><br><br><br>Thank you.We will contact you soon.</h2></center><br><br><br><br>
<center><div><button onclick="location.href='main.php'"class="w3-button w3-right w3-theme" >Back to Home</button></div></center>
</body>
</html>






