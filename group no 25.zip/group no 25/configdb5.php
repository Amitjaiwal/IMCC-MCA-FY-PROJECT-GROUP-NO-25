<?php
define ('a','localhost');
define ('b','root');
define ('c','');
define ('d','db5');
$db = mysqli_connect(a,b,c,d);
?>
 
