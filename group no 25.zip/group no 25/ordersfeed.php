<?php
session_start();
error_reporting(0);

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "db5";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

$sql1 = "SELECT * FROM feedback";

$result = $conn->query($sql1);
?>
<!DOCTYPE html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>View All Orders</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="css/main.css">
        <link href='http://fonts.googleapis.com/css?family=Roboto:400,300,500' rel='stylesheet' type='text/css'>
        <link href="//netdna.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css" rel="stylesheet">
        <script src="js/jquery-1.8.2.min.js"></script>
        <script src="js/jquery.validate.min.js"></script>
        <script src="js/main.js"></script>
		<style type="text/css">
		a:link {color: #ffffff}
		a:visited {color: #ffffff}
		a:hover {color: #ffffff}
		a:active {color: #ffffff}
		body{background: #333333 url(pizza-HD.jpg) no-repeat; background-size:100%; }
		</style>
    </head>
    <body>
	<?php include("configdb5.php"); ?>
<?php

?>
<h2 style="text-align:center; color:white">View Customer Feedback</h2>
		<div id="form-content">
		<br>
		<br>
		<br>
			<div class="welcome" style="background: white;">
				<table id="example3" class="table table-bordered table-striped" style="width:100%" border="1">
                <thead style="color: red;text-align: left;">
                <tr>
                	<th>overall experience</th>
                  <th>how much satisfied</th>
                  <th>scale of 0 to 5</th>
                  <th>Comments</th>
				  <th>Name</th>
				  <th>Email</th>
				
				  
                </tr>
                </thead>
                <tbody>
			<?php	if ($result->num_rows > 0) {
						// output data of each row
						while($row = $result->fetch_assoc()) { ?>
			<tr>
				<td ><h4 class="widget-user-username txt"><?php echo $row['q1']  ?></h4></td>
				  	<td ><h4 class="widget-user-username txt"><?php echo $row['q2']  ?></h4></td>			 
                  <td ><h4 class="widget-user-username txt"><?php echo $row['q3']  ?></h4></td>
                  <td ><h4 class="widget-user-username txt"><?php echo $row['co']  ?></h4></td>
                  <td ><h4 class="widget-user-username txt"><?php echo $row['nm']  ?></h4></td>
                  <td ><h4 class="widget-user-username txt"><?php echo $row['em']  ?></h4></td>
                 
				 
				  </h4></td>
                  
				  
			<?php }
						
					} else {
						echo "0 results";
					}
						?>
          </tbody>
               
              </table>
				
			</div>	
		</div>	 
    </body>
</html>