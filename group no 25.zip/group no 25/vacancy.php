<html>
   
   <head>
       <title>Quotation</title>
       
      <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
       <link rel="stylesheet" type="text/css" href="abc.css">
   

<script type="text/javascript">
  

  function allLetter(inputtxt)
  {
   var letters = /^[A-Za-z]+$/;
   if(inputtxt.value.match(letters))
     {
      return true;
     }
   else
     {
     alert("Please enter only alphabets in the name");
     inputtxt.value="";
     inputtxt.focus();
     return false;
     }
  }

function allLetter1(inputtxt)
  {
   var letters = /^[A-Za-z]+$/;
   if(inputtxt.value.match(letters))
     {
      return true;
     }
   else
     {
     alert("Please enter only alphabets in the comment");
     inputtxt.value="";
     inputtxt.focus();
     return false;
     }
  }


function allnumeric(inputtxt)
   {
      var numbers = /^[0-9]+$/;
      if(inputtxt.value.match(numbers))
      {
      
      return true;
      }
      else
      {
      alert('Please input digit only in mobile number');

      inputtxt.value="";
     inputtxt.focus();
      return false;
      }
   } 
                (function aa() {
                            //var altFormat = $( "#datepicker" ).datepicker( "option", "altFormat" );
                            $( "#datepicker" ).datepicker({ dateFormat: 'yy-mm-dd',changeYear:true,changeMonth:true,yearRange:'1900:2002'});
                            //getter
                            var dateFormat = $( "#datepicker" ).datepicker( "option", "dateFormat" );
                            //setter
                            $( "#datepicker" ).datepicker( "option", "dateFormat", 'yy-mm-dd' );
                        });




</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js">
  (function(){
    var dtToday = new Date();
    
    var month = dtToday.getMonth() + 1;
    var day = dtToday.getDate();
    var year = dtToday.getFullYear();
    if(month < 10)
        month = '0' + month.toString();
    if(day < 10)
        day = '0' + day.toString();
    
    var minDate= year + '-' + month + '-' + day;
    
    $('#txtDate').attr('min', minDate);
});
  
</script>

  </head>
         
      
      
  
   <Center><h1>Quality Packers and Movers</h1>
<br>

Service Request For Domestice Package
</Center><br>
   <body>

<div align="center">
    
         <div style = "width:600px; " align = "left">
            <div style = "color:white; padding:5px;"><b><center><h3>Quotation</center> </b></h3></div>
				
            <div style = "margin:30px">
              

                 <form  name="form1" action = "insert2.php" method = "post">
                   


                  <div class="form-group">
    						<label>Full Name</label>
    						<input type="text" name="t1" class="form-control" placeholder="Enter your name" required>
    					</div>
<div class="form-group">
    						<label>Mobile No</label>
    						<input type=maxlength="number" name="t2" class="form-control" maxlength="10" placeholder="Enter your number"required>
    					</div>
    					<div class="form-group">
    							<label>Pickup_date</label>
    						<input type="date" name="t3"  class="form-control" min="2021-09-01" max="2023-01-01" required>
    					</div>
						<div class="form-group">
						
    						<label>Pickup</label>
    						<input type="text" name="t4" class="form-control"placeholder="Enter pickup location" required>
    						</div>
						<div class="form-group">
						
    						<label>Drop</label>
    						<input type="text" name="t5" class="form-control"placeholder="Enter drop location" required>
    						</div>

    					<div class="form-group">
    						<label>Email</label>
    						<input type="Email" name="t6" class="form-control"placeholder="Enter your Email" required>
    					</div><div class="form-group">
    						<label>Comment</label>
    						<input type="text" name="t7" class="form-control" placeholder="Enter your message"required>
    					</div>
<div align="center">
                  <button type="submit" class="btn btn-primary" onclick="allLetter(document.form1.t1); allnumeric(document.form1.t2); allLetter1(document.form1.t7);functionaa(document.form1.t3);">Submit</button>    
               </form>
               
              
					
         </div>				
         </div>
			
      </div>

   </body>
</html>
