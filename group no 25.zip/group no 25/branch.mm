<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Branches</title>
		<meta charset="utf-8">
		<meta name="format-detection" content="telephone=no" />
		<link rel="icon" href="images/favicon.ico">
		<link rel="shortcut icon" href="images/favicon.ico" />
		<link rel="stylesheet" href="css/style.css">
		<script src="js/jquery.js"></script>
		<script src="js/jquery-migrate-1.2.1.js"></script>
		<script src="js/script.js"></script>
		<script src="js/superfish.js"></script>
		<script src="js/jquery.ui.totop.js"></script>
		<script src="js/jquery.equalheights.js"></script>
		<script src="js/jquery.mobilemenu.js"></script>
		<script src="js/jquery.easing.1.3.js"></script>
		<script>
		$(document).ready(function(){
			$().UItoTop({ easingType: 'easeOutQuart' });
		});
		</script>
	</head>
	<body>
<!--==============================header=================================-->
		<header>
			<div class="container_12">
				<div class="grid_1">
					<div class="menu_block">
				        <nav class="topnav-centered">
							<ul class="sf-menu">
								<li><a href="main.php">  Home</a></li>
							</ul>
						</nav>
						<div class="clear"></div>
					</div>
				</div>
				<div class="grid_12">
					<h1>
						<a href="index.html">
							<img src="images/branches.png" alt="Our branches">
						</a>
					</h1>
				</div>
			</div>
		</header>
		
<!--==============================Content=================================-->
		<div class="content"><div class="ic">More Website Templates @ TemplateMonster.com - February 10, 2014!</div>
			<div class="container_12" >
				<div class="banners" >
					<div class="grid_4">
						<div class="banner">
							<img src="images/ahmedabad.jpg" alt="">
							<div class="label">
								<div class="title"><u>AHMEDABAD</u></div><br>
								<div class="price"><span>Balaji Packers and Movers</span></div>
								<a href="https://www.google.com/maps/place/Balaji+Packers+%26+Movers/@23.109007,72.5339037,17z/data=!3m1!4b1!4m5!3m4!1s0x395e82d96d6cf8cf:0xe5a1756dd34536e5!8m2!3d23.109007!4d72.5360924">LOCATION</a>
							</div>
						</div>
					</div>
					<div class="grid_4">
						<div class="banner">
							<img src="images/mumbai.jpg" alt="">
							<div class="label">
								<div class="title"><u>MUMBAI</u></div><br>
								<div class="price"><span>Shree RK Packers & movers</span></div>
								<a href="https://www.google.com/maps/place/SHREE+R+K+PACKERS+AND+MOVERS/@19.2191373,72.9813566,17z/data=!3m1!4b1!4m5!3m4!1s0x3be7b96b0046c4c7:0xea4ca7966f00e409!8m2!3d19.2191373!4d72.9835453">LOCATION</a>
							</div>
						</div>
					</div>
					<div class="grid_4">
						<div class="banner">
							<img src="images/pune.jpg" alt="">
							<div class="label">
								<div class="title"><u>PUNE</u></div><br>
								<div class="price"><span>Om Sai packers and movers</span></div>
								<a href="https://www.google.com/maps/place/Om+Sai+Packers+and+Movers/@18.5203673,73.9375356,17z/data=!3m1!4b1!4m5!3m4!1s0x3bc2c3bdca1cf3eb:0x4ee04288691f3839!8m2!3d18.5203761!4d73.9396308">LOCATION</a>
							</div>
						</div>
					</div>
					<div class="clear"></div>
					<div class="grid_4">
						<div class="banner">
							<img src="images/delhi.jpg" alt="">
							<div class="label">
								<div class="title"><u>DELHI</u></div><br>
								<div class="price"><span>Sai Packers and movers</span></div>
								<a href="https://www.google.com/maps/place/Sai+Packers+And+Movers/@28.6242253,77.2808147,17z/data=!3m1!4b1!4m5!3m4!1s0x390ce59e6f88afa7:0x57663a3ba070895e!8m2!3d28.6242344!4d77.2830422">LOCATION</a>
							</div>
						</div>
					</div>
					<div class="grid_4">
						<div class="banner">
							<img src="images/bangalore1.jpg" alt="">
							<div class="label">
								<div class="title"><u>BANGALORE</u></div><br>
								<div class="price"><span>Century packers & movers</span></div>
								<a href="https://www.google.com/maps/place/Century+Packers+And+Movers/@12.9874961,77.7380093,17z/data=!3m1!4b1!4m5!3m4!1s0x3bae11b038f128c9:0xfd67ae7cd1bc6453!8m2!3d12.9874961!4d77.740198">LOCATION</a>
							</div>
						</div>
					</div>
					<div class="grid_4">
						<div class="banner">
							<img src="images/chennai1.jpg" alt="">
							<div class="label">
								<div class="title"><u>CHENNAI</u></div><br>
								<div class="price"><span>Arun packers and movers</span></div>
								<a href="https://www.google.com/maps/place/Arun+Packers+%26+Movers/@12.9279012,80.138476,17z/data=!3m1!4b1!4m5!3m4!1s0x3a525f02c882bd61:0x4f60d68d05c13639!8m2!3d12.927915!4d80.1406656">LOCATION</a>
							</div>
						</div>
					</div>
					<div class="clear"></div>
					<div class="grid_4">
						<div class="banner">
							<img src="images/hyderabad.jpg" alt="">
							<div class="label">
								<div class="title"><u>HYDERABAD</u></div><br>
								<div class="price"><span>Lion ex packers and movers</span></div>
								<a href="https://www.google.com/maps/place/Lion+Ex+Packers+%26+Movers/@17.9961731,77.7847589,8z/data=!3m1!4b1!4m5!3m4!1s0x3bcb9a78287f6dcf:0x2bd629c316758ccd!8m2!3d17.9993978!4d78.906087">LOCATION</a>
							</div>
						</div>
					</div>
					<div class="grid_4">
						<div class="banner">
							<img src="images/kolkata.jpg" alt="">
							<div class="label">
								<div class="title"><u>KOLKATA</u></div><br>
								<div class="price"><span>RK Packers and movers</span></div>
								<a href="https://www.google.com/maps/place/R+K+Packers+%26+Movers+Kolkata/@22.4748249,88.3562518,17z/data=!3m1!4b1!4m5!3m4!1s0x3a027b2cb470a261:0x4e3fba4ecdbd0f66!8m2!3d22.4748249!4d88.3584405">LOCATION</a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
<!--==============================footer=================================-->
		<!--<footer>
			<div class="container_12">
				<div class="grid_12">
					<div class="socials">
						<a href="#" class="fa fa-facebook"></a>
						<a href="#" class="fa fa-twitter"></a>
						<a href="#" class="fa fa-google-plus"></a>
					</div>
					<div class="copy">
						Your Trip (c) 2014 | <a href="#">Privacy Policy</a> | Website Template Designed by TemplateMonster.com
					</div>
				</div>
			</div>
		</footer>-->
		<!--<script>
		$(function (){
			$('#bookingForm').bookingForm({
				ownerEmail: '#'
			});
		})
		</script>-->
	</body>
</html>