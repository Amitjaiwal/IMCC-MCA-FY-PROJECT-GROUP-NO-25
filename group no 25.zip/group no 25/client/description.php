<?php require('database_connection.php'); ?>

<?php 
    $id = $_REQUEST['id'];
    $result = mysqli_query($con, "select * from clients where client_id = $id");
?>

<html>
    <head>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
        <link rel="stylesheet" type="text/css" href="style/style.css" />
    </head>

    <body>
        <div class="bg-image"></div>

        <div class="bg-text">
            <div class="container">
                <div class="row">
                    <?php if($row = mysqli_fetch_row($result)) { ?>
                        <div class="col-sm-6">
                            <img src="<?php echo $row[3]; ?>" class="img-thumbnail client-image" id="<?php echo $row[0]; ?>" style="width: 600px; height: 500px;">
                        </div>

                        <div class="col-sm-6">
                            <h2 style="text-align: left;">
                                <u> <?php echo $row[1]; ?> </u>
                            </h2>

                            <h4 style="text-align: justify;">
                                <?php echo $row[2]; ?>
                            </h4>
                        </div>
                    <?php } ?>
                </div>
            </div>        
        </div>
    </body>

    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</html>