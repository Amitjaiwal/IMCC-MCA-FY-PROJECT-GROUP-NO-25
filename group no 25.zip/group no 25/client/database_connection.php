<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "packers_and_movers";
    
    $con = mysqli_connect($servername, $username, $password, $database);
?>